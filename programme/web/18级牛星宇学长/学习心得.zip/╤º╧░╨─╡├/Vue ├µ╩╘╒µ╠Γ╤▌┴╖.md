# Vue 面试真题演练

## v-show 和 v-if 的区别

![image-20210819200334443](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819200334443.png)

## 为何在 v-for 中用 key

![image-20210819200420734](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819200420734.png)

## Vue组件的生命周期

![https://cn.vuejs.org/images/lifecycle.png](https://cn.vuejs.org/images/lifecycle.png)

## Vue 组件如何通讯（常见）

- 父子组件 props 和 this.$emit
- 自定义事件 event.$on、event.$off、event.$emit
- Vuex

## 描述组件渲染和更新的过程

<img src="C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819201603276.png" alt="image-20210819201603276" style="zoom:150%;" />

## 双向数据绑定 v-model 的实现原理

![image-20210819201814515](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819201814515.png)

假设 this.name 为 v-model 绑定的变量，在input 标签中使用 :value = "this.name" 对其进行绑定。  

同时添加一个事件 @input = "$emit('xxx', $event.target.value)",绑定 input 事件，使得 this.name = $event.target.value

![image-20210819082104481](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819082104481.png)

## 对 MVVM 的理解

![](https://img-blog.csdnimg.cn/20190218151740267.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzQxNzYxNTkx,size_16,color_FFFFFF,t_70)

## computed 有何特点

![image-20210819202609838](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819202609838.png)

## 为何 data 必须是一个函数

在每一个 .vue 文件中，实际上每一个组件都是一个类，使用该组件时就是对该组件的实例化。

1. vue中组件是用来复用的，为了防止data复用，将其定义为函数。
2. vue组件中的data数据都应该是相互隔离，互不影响的，组件每复用一次，data数据就应该被复制一次，之后，当某一处复用的地方组件内data数据被改变时，其他复用地方组件的data数据不受影响，就需要通过data函数返回一个对象作为组件的状态。

3. 当我们将组件中的data写成一个函数，数据以函数返回值形式定义，这样每复用一次组件，就会返回一份新的data，拥有自己的作用域，类似于给每个组件实例创建一个私有的数据空间，让各个组件实例维护各自的数据。

4. 当我们组件的date单纯的写成对象形式，这些实例用的是同一个构造函数，由于JavaScript的特性所导致，所有的组件实例共用了一个data，就会造成一个变了全都会变的结果。

#### 代码分析

vue每次会通过组件创建出一个构造函数，每个实例都是通过这个构造函数new出来的  

假如data是一个对象，将这个对象放到这个原型上去

~~~javascript
function VueComponent(){}
VueComponent.prototype.$options = {
    data:{name:'three'} 
}
let vc1 = new VueComponent();
vc1.$options.data.name = 'six'; // 将vc1实例上的data修改为six
let vc2 = new VueComponent(); // 在new一个新的实例vc2
console.log(vc2.$options.data.name); six
// 输出vc2的data的值是six，这时候发现vc2中的data也被修改了，他们data相互影响
~~~

将data改为一个函数

~~~javascript
// 这样就可以保证每个组件调用data返回一个全新的对象，和外部没有关系
function VueComponent(){}
VueComponent.prototype.$options = {
    data: () => ({name:'three'}) 
}
let vc1 = new VueComponent();
let objData = vc1.$options.data()
objData.name = 'six'; // 调用data方法会返回一个对象，用这个对象作为它的属性
console.log(objData)
let vc2 = new VueComponent();
console.log(vc2.$options.data());
~~~

## ajax 请求应该放在哪个生命周期

![image-20210819203434515](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819203434515.png)

## 如何将组件所有 props（属性） 传递给子组件

![image-20210819203724992](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819203724992.png)

## 何时要使用异步组件

![image-20210819204012856](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819204012856.png)

## 何时需要使用 keep-alive

![image-20210819203916937](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819203916937.png)

## 何时需要使用 beforeDestory

![image-20210819204052318](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819204052318.png)

## Vuex 中 action 和 mutation 有何区别

![image-20210819204137916](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819204137916.png)

## Vue-Router 常用的路由模式

![image-20210819204305227](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819204305227.png)

### 如何配置 Vue-Router 异步加载

![image-20210819204339623](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819204339623.png)

## 监听 data 变化的核心API是什么

Object.defineProperty，深度监听需要添加 Obverser  

Object.defineProperty 本身不能监听数组变化，因此需要重新定义原型，重写 push、pop等方法，实现监听

## 响应式原理

![image-20210819204853314](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819204853314.png)

## 简述 diff 算法过程

![image-20210819205110576](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819205110576.png)

## Vue 常见性能优化方式

![image-20210819205238077](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819205238077.png)

![image-20210819205250879](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819205250879.png)

![image-20210819205307128](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819205307128.png)

![image-20210819205318003](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819205318003.png)

