# Node.js

Node.js 中间层运行于后台服务和浏览器前端之间，将它用作服务端渲染，即SSR（ServerSideRendering），可以大幅提高搜索引擎抓取网页的效果，以及网页展现首屏的速度。



- Node.js 程序运行不稳定，经常出现服务不可用的情况
- Node.js 程序的运行效率低，每秒能处理的请求数维持在一个很低的水平
- 只学前端可能对服务端技术不熟悉



Node.js 拥有广大的 JavaScript 程序员基础，并且完开源，所以它拥有一个强大的开发者社区，依靠繁荣的社区力量，现在已经发展出成熟的技术体系，以及庞大的生态。它被广泛的用在 Web 服务、开发工作流、客户端应用等等诸多领域。其中，在 Web 服务开发这个领域，业界对 Node.js 的接受程度是最高的。通常它会被用来做一个 BFF 层，即 Backend For Frontend（服务于前端的后端），通俗的说就是一个专门用于为前端业务提供数据的后端程序。这类程序的特点是不需要太强的服务器运算能力，但对程序的灵活性有较高要求。这两个特点都正好和 Node.js 的优势相吻合。在 Web 服务开发领域搭建一个 Node.js BFF 层是有很大好处的：

1. 对于 Web 业务本身来说，Node.js 现在是最适合用来做 BFF 层的技术，有一个 Node.js BFF 层，能让前端有能力自由组装后台数据，这样可以减少大量的业务沟通成本，加快业务的迭代速度。同时，前端工程师能自主决定前端与后台通讯的方式，也让前端工程师有了更多的能力着手于 Web 应用的性能优化。
2. 对于后端和运维工程师来说，Node.js BFF 层的搭建绝对不是一个光靠前端工程师就能完成的事情，在搭建过程中涉及到的 RPC 调用、系统运维等等场景，都需要后端和运维的紧密接合。通过搭建 BFF 层，除了后续能够减少自己在繁重业务中的工作量之外，还可以大大提升自己在架构领域的知识经验。
3. 对于前端工程师自身来说，Node.js 虽然是一门非浏览器端的技术，但是它基于 JavaScript 的环境，能让前端工程师快速上手，学会一门非浏览器端的技术，经由 Node.js，涉及数据库、操作系统、人工智能等等技术领域，让前端工程师不会再因为技术的壁垒，将眼光局限在浏览器这一个环境内。

## 学习 Node.js 的难点

在使用 Node.js 的过程中，前端工程师需要了解诸如 RPC 调用，进程管理等等非浏览器端知识。



## Node.js (CommonJS) 模块规范

![image-20211114174021462](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20211114174021462.png)

**Node.js 的运行环境不经过任何 HTML 文件，使用 CommonJS 模块规范**

## 阿里前端训练生讲解

### Node.js 简介

Node.js 不是一门编程语言，而是一个运行时，将 JS 运行在服务器。编写程序的语言是 JavaScript，Node.js 靠 Chrome V8 引擎运行 JavaScript。

动态性语言不需要编译，只需要依赖引擎直接实时运行代码。

服务器为什么要使用 JavaScript？ => 使用其他语言不是前端与生具备，使用 JS 学习成本更低;JS 具有跨平台的特性；JS 依赖 V8 引擎，性能极高，能够稳定运行；事件驱动，监听鼠标点击、键盘等事件。

Node 扩展了 JS 的能力，基于浏览器的安全，浏览器不允许 JS 访问本地文件，Node.js 扩展了这一能力，可以搭建服务器，连接数据库，给JS 带来了更多想象的空间，可以跑在浏览器和服务器端，前后端通吃，保证前端人员学习成本很低就可以完成前后端开发。

Node.js 基于事件驱动，适合 I/O 密集型操作，比如服务的调用，作为桥梁担任接入层，调接口，读取文件。但不适合CPU密集型，比如运算，如当一个游戏去运行

### 模块管理 NPM

NPM 是为了让 Node.js 的文件可以相互调用一个简单的模块管理系统。

~~~javascript
mkdir test-demo
cd test-demo

npm init
~~~

![image-20211113142551042](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20211113142551042.png)

通过 exports 暴露需要导出的内容，通过 require 导入

![image-20211113143036552](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20211113143036552.png)

![image-20211113143047043](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20211113143047043.png)

### 内置核心模块（文件处理、网络编程等）

## 前端工程体系

### 工程体系概述

什么是前端工程？

![image-20211114091345657](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20211114091345657.png)

![image-20211114091541543](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20211114091541543.png)

### 初始化

![image-20211114091642532](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20211114091642532.png)



当运行项目时，如果修改了文件，noe 能够自动加载修改的文件



早年使用 Gulp 等，突然间产生了新的工具，如 require.js ，将模块按需加载，用着用着又产生了 Webpack，可以将模块化打包。plugins 能够对文件进行处理， loader 是单纯的文件转换过程，只能够编译成新文件。它涵盖了任务流构建工具的很多功能 



框架和工具类对于单元测试有需求，业务类较少。



## 从前端框架到前端框架

![image-20211114142058760](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20211114142058760.png)



单页面应用一次性加载所有数据，不需要多次请求数据

## Express / Koa

核心功能：

1. 
   + 比 express 更极致的 requset/response 简化
     - ctx.status = 200
     - ctx.body = 'hello world'
2. 
   + 使用 async function 实现的中间件
     * 有“暂停执行”的能力
     * 在异步的情况下也符合洋葱模型
3. 
   * 精简内核，所有额外功能都移到中间件里实现。



Express vs Koa

* express 门槛更低，koa更强大优雅。
* express 封装更多东西，开发更快速，koa 可定制型更高。
