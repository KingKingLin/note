# Vue2 考点总结

## Vue2 基本使用

### computed 和 watch 区别

computed 可以缓存，即若 data 不变，则 computed 不会重新计算。  

![image-20210820103340573](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210820103340573.png)

computed返回的应当是一个对象：

![image-20210820105856798](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210820105856798.png)

watch 默认为浅监听，即对于引用类型无法深度监听，需要添加 deep: true

![image-20210819111100237](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819111100237.png)

其中，info是一个对象

![image-20210819111156566](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819111156566.png)

使用 watch 对其进行监听时，需要写入一个 handler 函数来进行监听后的操作。

其实道理很简单，属于vue2.0的坑，其实就是：在变异 (不是替换) 对象或数组时，旧值将与新值相同，因为它们的引用指向同一个对象/数组。Vue 不会保留变异之前值的副本；

### 组件通讯

#### 父子组件通讯

常用的如 props 和$emit，即父组件给子组件传递数据，子组件向父组件触发事件。  

例如此处在父组件中绑定list数据

![image-20210819074736512](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819074736512.png)

  

然后在子组件中添加 props 接收该数据即可。

![image-20210819074839300](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819074839300.png)

同时在子组件中调用父组件在使用子组件时绑定的事件。

![image-20210819075449642](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819075449642.png)

#### 自定义事件

自定义事件可以在许多情况中使用，不会只限制在父子组件/兄弟组件中。  

![image-20210819075159003](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819075159003.png)

如图，在这里创建一个名为 'onAddTitle' 的自定义事件，每次触发该事件时执行第二个参数中的函数。

![image-20210819075359140](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819075359140.png)

在另一组件中触发该自定义事件，第二个参数为传递过去的参数。

### 生命周期

![https://cn.vuejs.org/images/lifecycle.png](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\lifecycle.png)

在父子组件中，调用顺序遵从“从外到内，再从内到外，mixins先于组件”的原则。

### vue 高级特性

#### 如何自己实现 v-model

用于双向绑定表单元素，与 v-bind 类似，子组件中定义 props，

![image-20210819082104481](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819082104481.png)

而在父组件中，仅仅使用了 v-model即可。

![image-20210819082214428](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819082214428.png)

#### $nextTick

Vue 是一个异步渲染的框架，即 data 改变之后，dom 不会立刻渲染，而是异步进行渲染。  

因此想要在 dom 改变之后立刻获取到其中的数据，需要调用 $nextTick，它会在 dom 渲染之后被触发，以获取最新 dom 节点。

#### slot

可以帮助父组件往子组件中插入一些内容。  

在父组件中调用子组件，同时动态绑定 url

![image-20210819085512988](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819085512988.png)

子组件内容如下，由于父组件中已经写入了数据，因此子组件中默认的 slot 不会执行，她只会在父组件没有内容写入时默认显示。

![image-20210819085533717](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819085533717.png)

  

##### 具名插槽

![image-20210819090812766](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819090812766.png)

  

##### 作用域插槽

较为高级的用法为作用域插槽，此时父组件可以获取子组件中的数据。

首先在子组件中定义一个动态属性 slotData

![image-20210819090436823](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819090436823.png)

在父组件中进行调用，格式进行如下更改

![image-20210819090536610](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819090536610.png)

v-slot 中定义的 slotProps 名字不唯一，可以是任意名字。

#### 动态组件

![image-20210819091722853](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819091722853.png)

使用格式如下

![image-20210819091758574](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819091758574.png)

#### 异步组件

import() 函数  

![image-20210819092913682](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819092913682.png)

该组件只会在被使用的时候才被加载，可以提升性能。  即按需加载，异步加载大组件

#### keep-alive

用来缓存组件，在需要频繁切换的组件之中且不需要重复渲染时使用，亦可用于性能优化。

![image-20210819100421311](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819100421311.png)

#### 使用 mixin 抽离公共逻辑

多个组件见公用相同的逻辑，则将其写入mixin，将公共的部分抽离，之后每个组件复用即可。

#### Vuex

![https://vuex.vuejs.org/vuex.png](https://vuex.vuejs.org/vuex.png)

只有 Actions 中能够进行异步操作，Mutations 是原子操作。因此 Actions 中可能会整合一个或多个 Mutations 的 Commit 操作。

#### Vue-Router

![image-20210819105738754](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819105738754.png)

![image-20210819105812289](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819105812289.png)

![image-20210819110314158](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819110314158.png)

## Vue 原理

### 组件化基础

#### MVVM模型

数据驱动视图（MVVM，setState）

![vue中MVVM的体现](https://img-blog.csdnimg.cn/20190218151740267.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzQxNzYxNTkx,size_16,color_FFFFFF,t_70)

<img src="https://img-blog.csdnimg.cn/20190218151600647.jpeg?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L3FxXzQxNzYxNTkx,size_16,color_FFFFFF,t_70" alt="MVVM模型图示" style="zoom: 150%;" />

### Vue 响应式

#### 核心API - Object.defineProperty

[https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/defineProperty](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/defineProperty)

```javascript
// 触发更新视图
function updateView() {
    console.log('视图更新')
}

// 重新定义数组原型
const oldArrayProperty = Array.prototype
// 创建新对象，原型指向 oldArrayProperty ，再扩展新的方法不会影响原型
const arrProto = Object.create(oldArrayProperty);
['push', 'pop', 'shift', 'unshift', 'splice'].forEach(methodName => {
    arrProto[methodName] = function () {
        updateView() // 触发视图更新
        oldArrayProperty[methodName].call(this, ...arguments)
        // Array.prototype.push.call(this, ...arguments)
    }
})

// 重新定义属性，监听起来
function defineReactive(target, key, value) {
    // 深度监听
    observer(value)

    // 核心 API
    Object.defineProperty(target, key, {
        get() {
            return value
        },
        set(newValue) {
            if (newValue !== value) {
                // 深度监听
                observer(newValue)

                // 设置新值
                // 注意，value 一直在闭包中，此处设置完之后，再 get 时也是会获取最新的值
                value = newValue

                // 触发更新视图
                updateView()
            }
        }
    })
}

// 监听对象属性
function observer(target) {
    if (typeof target !== 'object' || target === null) {
        // 不是对象或数组
        return target
    }

    // 污染全局的 Array 原型
    // Array.prototype.push = function () {
    //     updateView()
    //     ...
    // }

    if (Array.isArray(target)) {
        target.__proto__ = arrProto
    }

    // 重新定义各个属性（for in 也可以遍历数组）
    for (let key in target) {
        defineReactive(target, key, target[key])
    }
}

// 准备数据
const data = {
    name: 'zhangsan',
    age: 20,
    info: {
        address: '北京' // 需要深度监听
    },
    nums: [10, 20, 30]
}

// 监听数据
observer(data)

// 测试
// data.name = 'lisi'
// data.age = 21
// // console.log('age', data.age)
// data.x = '100' // 新增属性，监听不到 —— 所以有 Vue.set
// delete data.name // 删除属性，监听不到 —— 所有已 Vue.delete
// data.info.address = '上海' // 深度监听
data.nums.push(4) // 监听数组
```

![image-20210819142818854](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819142818854.png)

### 虚拟 （Virtual DOM）DOM

DOM 操作非常耗费性能，因此使用 JS 模拟 DOM 结构，计算出最小的变更来操作 DOM。

![image-20210819145439404](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819145439404.png)

render函数 => h函数生成一个 vnode，如果有更新则通过 **patch** 函数更新 vnode，没有更新则直接渲染。 

![image-20210819153611037](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819153611037.png)

### diff 算法

两棵树之间做 diff 的时间复杂度是 O(n^3)，因此普通方法是不能使用的，需要优化算法。

![image-20210819154438874](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819154438874.png)

![image-20210819154735209](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819154735209.png)

![image-20210819154806952](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819154806952.png)

#### diff算法源码解析 - snabbdom

·



### 模板编译

![image-20210819162308647](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819162308647.png)

![image-20210819162746170](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819162746170.png)

![image-20210819163324873](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819163324873.png)



其中，_c 代表 createElement，实际上就是h函数；

​		   _v代表 createTextVNode；

​		   _s代表 toString

![image-20210819164604042](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210819164604042.png)

### 组件 渲染/更新 过程

![image-20210819174539664](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819174539664.png)

![image-20210819175007032](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819175007032.png)

![image-20210819175155540](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819175155540.png)

![image-20210819175217446](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819175217446.png)

### 异步渲染

通过异步操作可以汇总 data 的修改，从而做到一次性更新视图，减少了 DOM 的操作次数，提高性能。

### 路由

#### 用 JS 实现 hash 路由

![image-20210819180040655](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819180040655.png)

![image-20210819191302457](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819191302457.png)

![image-20210819192551618](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819192551618.png)

通过 onhashchange 来监听 hash的变化



#### 用 JS 实现 H5 histroy 路由

![image-20210819193019165](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819193019165.png)

![image-20210819194451450](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Vue\Vue2\image-20210819194451450.png)

