# Vue3 考点总结

## Vue3 比 Vue2 的优势

![image-20210820090548268](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820090548268.png)

## Vue3 生命周期

#### Options API 生命周期

![image-20210820090841611](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820090841611.png)

#### Composition API 生命周期

![image-20210820091525508](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820091525508.png)

在 Composition API 中，使用  setup () 函数代替了  beforeCreate 和 created，其余的生命周期需要前置一个on，如 onBeforeMount，同时需要进行引入。

![image-20210820091810560](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820091810560.png)

## Composition API 和 Options API

#### Composition API

![image-20210820092638673](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820092638673.png)

![image-20210820093532829](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820093532829.png)

## 如何理解 ref toRef 和 toRefs

#### ref

![image-20210820094143196](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820094143196.png)

ref 可以用于响应式数据，它可以将基本类型数据转变为响应式数据。  

复杂类型如对象、数组这种则需要通过 reactive 来转换。  

同时， ref也被用来给元素或子组件注册引用信息， 引用信息将会注册在父组件的 $refs 对象上，如果是在普通的DOM元素上使用，引用指向的就是 DOM 元素，如果是在子组件上，引用就指向组件的实例。

具体详见https://cloud.tencent.com/developer/article/1479575

#### toRef

![image-20210820095647539](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820095647539.png)

写法如下：

![image-20210820095833041](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820095833041.png)

总的来说，toRef 用于在一个响应式对象中，其中某个属性单独拿出实现响应式。

#### toRefs

![image-20210820100344192](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820100344192.png)

![image-20210820100941876](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820100941876.png)

这样写的好处是在模板中使用时，可以直接引用变量而不需要在前面添加对应的对象名，如state.age

![image-20210820101032223](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820101032223.png)

在 composition API 中，toRefs 有一些极佳的使用方式

![image-20210820101351196](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820101351196.png)

![image-20210820101524124](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820101524124.png)

#### 进阶，深入理解

##### 为何需要用 ref ？

![image-20210820102333055](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820102333055.png)

##### 为何需要 .value

![image-20210820103530879](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820103530879.png)

##### 为何需要 toRef 和 toRefs

![image-20210820110945794](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820110945794.png)

## Vue3 升级的重要功能

![image-20210820111257627](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820111257627.png)

![image-20210820111519934](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820111519934.png)

#### createApp

![image-20210820111614599](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820111614599.png)

#### emits (声明)

![image-20210820112004570](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820112004570.png)

父组件向子组件传递一个事件，子组件需要通过 emits 声明一下该事件，然后在 setup函数中调用该事件，与 Vue2 的 $emit 类似。

#### 多事件处理

![image-20210820112418969](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820112418969.png)

比较简单，就是在methods中可以定义多个事件

#### Fragment

Vue2 中最外层必须包裹单一根节点，Vue3不再需要。

![image-20210820112534020](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820112534020.png)

#### 移除 .sync

![image-20210820112603519](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820112603519.png)



#### 异步组件

![image-20210820113150790](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820113150790.png)

#### 移除 filter

![image-20210820113249139](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820113249139.png)

#### Teleport

![image-20210820113522453](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820113522453.png)

Teleport 可以将组件放在外面，上图中便将 Teleport 中的内容放置在了 body 中

#### Suspense![image-20210820113655074](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820113655074.png)

在加载 Test1 的内容时，先显示 #fallback 中的内容，即先显示 Loading...  

等到 Test1 中的内容加载完毕后再替换为 Test1  

#### Composition API

![image-20210820114113271](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820114113271.png)

![image-20210820164103142](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820164103142.png)

![image-20210820213814368](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820213814368.png)



## Vue3如何实现响应式

在 Vue2 中的响应式基于 Object.defineProperty，但其具有一些缺点。如：

- 深度监听需要递归到底
- 无法监听新增属性/删除属性（需要使用Vue.set/Vue.delete）
- 无法原生监听数组，需要特殊处理

因此 Vue3 采用了 ES6 中的 Proxy 来实现响应式。

![image-20210820164809867](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820164809867.png)

Proxy 可以做到原生监听数组，不再需要重新定义数组原型

### Proxy 基本使用

~~~vue
const data = {
    name: 'zhangsan',
    age: 20,
}
// const data = ['a', 'b', 'c']

const proxyData = new Proxy(data, {
    get(target, key, receiver) {
        // 只处理本身（非原型的）属性
        const ownKeys = Reflect.ownKeys(target)
        if (ownKeys.includes(key)) {
            console.log('get', key) // 监听
        }

        const result = Reflect.get(target, key, receiver)
        // console.log(`result=${result}`)	
        return result // 返回结果
    },
    set(target, key, val, receiver) {
        // 重复的数据，不处理
        if (val === target[key]) {
            return true
        }

        const result = Reflect.set(target, key, val, receiver)
        console.log('set', key, val)
        // console.log('result', result) // true
        return result // 是否设置成功
    },
    deleteProperty(target, key) {
        const result = Reflect.deleteProperty(target, key)
        console.log('delete property', key)
        // console.log('result', result) // true
        return result // 是否删除成功
    }
})
~~~



每一个 Reflect 需与 Proxy 对应， Proxy 作为代理，Reflect 作为反射。

### Reflect 作用

![image-20210820175205847](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820175205847.png)

### 用 Proxy 实现响应式

与 Vue2 不同，Vue2 的响应式一旦监听了某一对象，会一次性递归完成，得到对象中的所有层级。  

Vue3 的响应式只会在需要的层级触发响应式。

~~~vue
// 创建响应式
function reactive(target = {}) {
    if (typeof target !== 'object' || target == null) {
        // 不是对象或数组，则返回
        return target
    }

    // 代理配置
    const proxyConf = {
        get(target, key, receiver) {
            // 只处理本身（非原型的）属性
            const ownKeys = Reflect.ownKeys(target)
            if (ownKeys.includes(key)) {
                console.log('get', key) // 监听
            }
    
            const result = Reflect.get(target, key, receiver)
        
            // 深度监听
            // 性能如何提升的？
            return reactive(result)
        },
        set(target, key, val, receiver) {
            // 重复的数据，不处理
            if (val === target[key]) {
                return true
            }
    
            const ownKeys = Reflect.ownKeys(target)
            if (ownKeys.includes(key)) {
                console.log('已有的 key', key)
            } else {
                console.log('新增的 key', key)
            }

            const result = Reflect.set(target, key, val, receiver)
            console.log('set', key, val)
            // console.log('result', result) // true
            return result // 是否设置成功
        },
        deleteProperty(target, key) {
            const result = Reflect.deleteProperty(target, key)
            console.log('delete property', key)
            // console.log('result', result) // true
            return result // 是否删除成功
        }
    }

    // 生成代理对象
    const observed = new Proxy(target, proxyConf)
    return observed
}

// 测试数据
const data = {
    name: 'zhangsan',
    age: 20,
    info: {
        city: 'beijing',
        a: {		//在这里输入 proxyData.info.a，则会得到 Proxy{b: {…}}的结果
            b: {
                c: {
                    d: {
                        e: 100
                    }
                }
            }
        }
    }
}

const proxyData = reactive(data)
~~~

![image-20210820200757752](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820200757752.png)

![image-20210820200840664](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820200840664.png)

## watch 和 watchEffect 的区别

watch需要配置第三个参数来实现初始化之前监听以及深度监听。

![image-20210820203943614](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820203943614.png)

watchEffect 会在初始化后执行一次，且只会监听写在该函数中的内容。

![image-20210820203822400](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820203822400.png)

## setup 中如何获取组件实例

![image-20210820204132828](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820204132828.png)

![image-20210820204420486](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820204420486.png)![image-20210820204430913](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820204430913.png)

## 编译优化

### PatchFlag

![image-20210820205616977](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820205616977.png)

![image-20210820210817108](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820210817108.png)

### hoistStatic 和 CacheHandler

![image-20210820214201188](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820214201188.png)

![image-20210820214148550](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820214148550.png)

### SSR 和 Tree-shaking 优化

![image-20210820211925568](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820211925568.png)

![image-20210820211947903](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210820211947903.png)

Tree-shaking会按需引入，用到才引入

## JSX

jsx 语法最终辸被编译成 JS

这里使用 Babel Plugin JSX for Vue 3.0

~~~
yarn add @vue/babel-plugin-jsx -D
~~~

