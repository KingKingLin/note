# 关于学习 Nest.js 的感想

其实学习下来感觉个人非常喜欢 Nest.js，但比较可惜的是在国内不温不火，毕竟国内的公司感觉大多都偏向直接用 Golang 或者 Java 这种后端语言来写后端，甚至于 egg.js。但 Nest 作为一个 Node.js 的 web server 框架，在我学习前后端交互时有所获益。

之前有幸参加过武汉的前端充电站，根据淘系团队的讲解，感觉 midway 也很有学习的价值，之后可以参考学习。 

## 框架简介

> Nest 是一个用于构建高效，可扩展的 [Node.js](http://nodejs.cn/) 服务器端应用程序的框架。它使用渐进式 JavaScript，内置并完全支持 [TypeScript](https://www.tslang.cn/)（但仍然允许开发人员使用纯 JavaScript 编写代码）并结合了 OOP（面向对象编程），FP（函数式编程）和 FRP（函数式响应编程）的元素。
>
> 在底层，Nest使用强大的 HTTP Server 框架，如 Express（默认）和 Fastify。Nest 在这些框架之上提供了一定程度的抽象，同时也将其 API 直接暴露给开发人员。这样可以轻松使用每个平台的无数第三方模块。

简单来说， Nest.js 是一款 Node.js 的后端框架，胜在**规范化**和**开箱即用**，在国外开发者社区非常流行，值得尝试一下。

## 前置准备

- TypeScript/JavaScript
- HTTP
- MySQL/MongoDB, etc
- Node.js >= 10.13.0

官网给出了使用 Nest.js 构建项目的方法，建议使用 Nest CLI 构建项目，脚手架的好处在于相关项目文件的生成便利。

~~~
npm i -g @nestjs/cli
nest new project-name
~~~

初始化项目后，进入该项目运行即可。

~~~
cd project-name
yarn start:dev		//使用 dev 模式启动可以自动监测文件内容的变化，并自动重启服务，便于开发。
~~~

> 此命令启动 HTTP 服务监听定义在 `src/main.ts` 文件中定义的端口号。在应用程序运行后, 打开浏览器并访问 `http://localhost:3000/`。 你应该看到 `Hello world!` 信息。

接下来需要使用 MySQL 操作数据库，当然并不只限于它，任何你偏好的 SQL 或 NoSQL 皆可，这里我使用 MySQL 进行学习。

## 代码编写

后端主要遵循 MVC 模式。同理，Nest.js 分为 controller、service 和 model，分别定义了路由，数据库操作以及数据库的模型。

以最经典的用户模块来看，编写一个后端的用户接口，来完成登录注册的相关内容。

### 创建 Module

首先创建一个`User`模块

~~~ 
nest g module user server
~~~

Nest CLi 会在 `src/server/user`下创建一个名为 `user.module.ts`的文件，它用来组织应用程序结构。

~~~
// user.module.ts
import { Module } from '@nestjs/common';

@Module({})
export class UserModule {}
~~~

我们需要在根模块中引入 User 模块来使用它，即`app.module.ts`，但基于上面创建 User 模块的指令，`app.module.ts`中的代码已经自行引入该模块。

~~~
// app.module.ts
import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserModule } from './server/user/user.module'; // 自动引入

@Module({
  imports: [UserModule], // 自动引入
  controllers: [AppController],
  providers: [AppService]
})
export class AppModule {}
~~~

### 创建 Controller

@Controll 装饰器用来处理对应的请求路由，控制器的目的是接收应用的特定请求。**路由**机制控制哪个控制器接收哪些请求。通常，每个控制器有多个路由，不同的路由可以执行不同的操作。

与上面同理，输入以下内容

~~~
nest g controller user server
~~~

会发现`src/server/user`中多了一个`user.controller.ts`文件，它用来处理相应的路由请求。

~~~
// user.controller.ts
import { Get } from '@nestjs/common';
import { UserService } from './user.service';
interface UserResponse<T = [] | boolean | User> {
  code: number;
  data?: T;
  message: string;
}

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Get('users')
  async findAll(): Promise<UserResponse<User[]>> {
    return {
      code: 200,
      data: await this.userService.findAll(),
      message: 'Success.',
    };
  }
}
~~~

这里我们导入一个 Get 方法，并创建了一个路径为`user/users`的路由，当我们通过Get 请求访问`http://localhost:3000/user/users`时，会返回该异步方法的结果。

在创建 Controller 文件时，引入了 `./user.service`，是因为 controller 并不能直接查询数据库并返回结果，而是需要转交给 Provider来处理，这种方式很常见，例如 Redux Thunk、Vuex。

### 创建 Provider

~~~
nest g service user server
~~~

`provider` 我们可以简单地从字面意思来理解，就是**服务的提供者**，它可以提供相应的**数据库操作服务**。

`Providers` 是纯粹的 `JavaScript` 类，在其类声明之前带有 `@Injectable()`装饰器。

~~~
// user.service.ts
import { Injectable } from '@nestjs/common';

@Injectable()
export class UserService {}
~~~

这里创建的了service 用来进行数据库操作，事实上它还可以进行一些校验操作。比如 **JWT** 登录校验等，封装一个对用户权限进行校验的策略类来为模块提供响应的服务。

最终 `user.moudule.ts`文件变成如下结果

~~~
// user.module.ts
import { Module } from '@nestjs/common';
import { UserController } from './user.controller';
import { UserService } from './user.service';

@Module({
  controllers: [UserController],
  providers: [UserService]
})
export class UserModule {}
~~~

此时，基本的内容有所完成，我们可以开始连接数据库了。

## 数据库相关操作

### 连接 MySQL 数据库

> 为了与 `SQL`和 `NoSQL` 数据库集成，`Nest` 提供了 `@nestjs/typeorm` 包。`Nest` 使用[TypeORM](https://github.com/typeorm/typeorm)是因为它是 `TypeScript` 中最成熟的对象关系映射器( `ORM` )。因为它是用 `TypeScript` 编写的，所以可以很好地与 `Nest` 框架集成。为所选数据库安装相关的客户端 `API` 库。

我是用的是 MySQL，需要安装相应的`API`库

~~~
npm install --save @nestjs/typeorm typeorm mysql2
~~~

将 `TypeOrmModule` 导入`AppModule` 。

~~~
// app.module.ts
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Connection } from 'typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserModule } from './server/user/user.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost',
      port: XXXX,
      username: 'XXXXX',
      password: 'XXXXXX',
      database: 'users_info',
      entities: [__dirname + '/**/*.entity{.ts,.js}'],
      synchronize: false,
    }),
    UserModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {
  constructor(private connection: Connection) {}
}
~~~

接下来就是 数据库的`CRUD`，来完善我们的登录注册接口。

### CRUD

CRUD，意为对数据库的增删改查。

此前我们已经写好了模块（Module）、路由（Controller）、以及相关的数据库操作服务（Provider）。实际上，Controller 中并不能直接更改数据库，它需要调用 Provider 中的方法来操作数据库，因此我们在 `user.service.ts`中增加一些操作，并使用 `async` 函数来处理异步的过程。。

~~~~
import { Injectable } from '@nestjs/common';
import { User } from './user.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { CreateUserDTO, EditUserDTO, LoginUserDTO } from './user.dto';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
  ) {}

  // 查找所有用户
  async findAll(): Promise<User[]> {
    const users = await this.userRepository.find();
    return users;
  }

  // 查找单个用户
  async findOne(id: string): Promise<User> {
    return await this.userRepository.findOne(id);
  }

  // 添加单个用户
  async addOne(body: CreateUserDTO): Promise<void> {
    await this.userRepository.insert(body);
  }

  // 编辑单个用户
  async editOne(id: string, body: EditUserDTO): Promise<void> {
    await this.userRepository.update(id, body);
  }

  // 删除单个用户
  async deleteOne(id: string): Promise<void> {
    await this.userRepository.delete(id);
  }

  // 登录
  async loginOne(body: LoginUserDTO): Promise<boolean> {
    const user = await this.userRepository.findOne(body.id);
    if (user.password === body.password) {
      return true;
    } else {
      return false;
    }
  }
}
~~~~

这个时候，我们需要在`src/user`路径中新增一个名为`user.dto.ts`的文件，使用其来对数据类型进行定义，用以规范数据。

~~~
// user.dto.ts
export class CreateUserDTO {
  readonly id: string;
  readonly name: string;
  readonly password: string;
}

export class EditUserDTO {
  readonly name: string;
  readonly password: string;
}

export class LoginUserDTO {
  readonly id: string;
  readonly password: string;
}
~~~

如此，我们可以在 `user.controller.ts` 中设置路由并调用相应方法了。

~~~
// user.controller.ts
import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
} from '@nestjs/common';
import { UserService } from './user.service';
import { User } from './user.entity';
import { CreateUserDTO, EditUserDTO, LoginUserDTO } from './user.dto';

interface UserResponse<T = [] | boolean | User> {
  code: number;
  data?: T;
  message: string;
}

@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Get('users')
  async findAll(): Promise<UserResponse<User[]>> {
    return {
      code: 200,
      data: await this.userService.findAll(),
      message: 'Success.',
    };
  }

  // GET /user/:id
  @Get(':id')
  async findOne(@Param('id') id: string): Promise<UserResponse<User>> {
    const data = await this.userService.findOne(id);
    if (data) {
      return {
        code: 200,
        data: data,
        message: 'Success.',
      };
    } else {
      return {
        code: 404,
        data: null,
        message: 'Can not found.',
      };
    }
  }

  // POST /user
  @Post()
  async addOne(@Body() body: CreateUserDTO): Promise<UserResponse> {
    await this.userService.addOne(body);
    return {
      code: 200,
      message: 'Success.',
    };
  }
  // POST /user/login
  @Post('/login')
  async loginOne(@Body() body: LoginUserDTO): Promise<UserResponse> {
    return {
      code: 200,
      data: await this.userService.loginOne(body),
      message: 'Success.',
    };
  }

  // PUT /user/:id
  @Put(':id')
  async editOne(
    @Param('id') id: string,
    @Body() body: EditUserDTO,
  ): Promise<UserResponse> {
    await this.userService.editOne(id, body);
    return {
      code: 200,
      data: await this.userService.findOne(id),
      message: 'Success.',
    };
  }

  // DELETE /user/:id
  @Delete(':id')
  async deleteOne(@Param('id') id: string): Promise<UserResponse> {
    await this.userService.deleteOne(id);
    return {
      code: 200,
      message: 'Success.',
    };
  }
}
~~~

如此便完成了一个基本的 `CRUD` 操作，可以通过 `Postman` 或者 `Swagger` 之类的接口自测工具进行测试。

### 接口测试

#### GET /user/users

![image-20210922222815825](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210922222815825.png)

这里我已经添加一些初始数据。

#### POST /users

![image-20210923004604125](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210923004604125.png)

向其中写入一条数据，返回写入成功的响应。

#### GET /user/:id

![image-20210923004822710](C:\Users\Kirito\Desktop\NestJs\image-20210923004822710.png)

查看刚才写入的用户信息，返回成功。

#### PUT /user/:id

有时我们需要修改用户数据，这时需要发送一个 `PUT` 请求

![image-20210923005052789](C:\Users\Kirito\Desktop\NestJs\image-20210923005052789.png)

#### DELETE /user/:id

![image-20210923005131674](C:\Users\Kirito\Desktop\NestJs\image-20210923005131674.png)

再去查看该`id`对应的用户，已经找不到了。

![image-20210923010019689](C:\Users\Kirito\Desktop\NestJs\image-20210923010019689.png)

如此，便完成了一个基本的 `CRUD`，前端通过`ajax`请求访问该端口，通过不同方法即可请求到数据，做到了前后端交互。

## 总结

其实在学习过程中还是遇到了很多坑的，自己也是查阅了官方文档以及许多优秀作者的博客才得以理解这些基本的功能，。简单来说 `Nest.js`是一个比较好用的 `Node.js`应用，但其中还有很多东西可以完善，我们大可以进行对数据库数据进行更多限制，以及一些错误捕获，还有之前提到的 **JWT**登陆校验等等，都是我们完善的方向。这个就需要后面去研究学习了。

对作为学习前端的我来说，这让我了解了部分后端的工作，便于理解前后端交互的过程。

接下来对 Midway 非常感兴趣，希望有时间能够研究一下。