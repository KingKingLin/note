

# React 基本使用

## JSX 基本使用



![image-20210821083315509](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210821083315509.png)

> ​    // 1. event 是 SyntheticEvent ，模拟出来 DOM 事件所有能力
>
> ​    // 2. event.nativeEvent 是原生事件对象
>
> ​    // 3. **在 React 16中，所有的事件，都被挂载到 document 上。但在 React 17后，事件绑定到 root 组件上** 
>
> ​	// 4. 在 Vue 中,event 是原生的的，且事件被挂载到当前元素。 
>
> ​    // 4. 和 DOM 事件不一样，和 Vue 事件也不一样

## 组件通讯

![image-20210821093012866](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210821093012866.png)

## setState

~~~react
import React from 'react'

// 函数组件（后面会讲），默认没有 state
class StateDemo extends React.Component {
    constructor(props) {
        super(props)

        // 第一，state 要在构造函数中定义
        this.state = {
            count: 0
        }
    }
    render() {
        return <div>
            <p>{this.state.count}</p>
            <button onClick={this.increase}>累加</button>
        </div>
    }
    increase = () => {
        // // 第二，不要直接修改 state ，使用不可变值 ----------------------------
        // // this.state.count++ // 错误
        // this.setState({
        //     count: this.state.count + 1 // SCU
        // })
        // 操作数组、对象的的常用形式

        // 第三，setState 可能是异步更新（有可能是同步更新） ----------------------------
        
        // this.setState({
        //     count: this.state.count + 1
        // }, () => {
        //     // 联想 Vue $nextTick - DOM
        //     console.log('count by callback', this.state.count) // 回调函数中可以拿到最新的 state
        // })
        // console.log('count', this.state.count) // 异步的，拿不到最新值

        // // setTimeout 中 setState 是同步的
        // setTimeout(() => {
        //     this.setState({
        //         count: this.state.count + 1
        //     })
        //     console.log('count in setTimeout', this.state.count)
        // }, 0)

        // 自己定义的 DOM 事件，setState 是同步的。再 componentDidMount 中

        // 第四，state 异步更新的话，更新前会被合并 ----------------------------
        
        // // 传入对象，会被合并（类似 Object.assign ）。执行结果只一次 +1
        // this.setState({
        //     count: this.state.count + 1
        // })
        // this.setState({
        //     count: this.state.count + 1
        // })
        // this.setState({
        //     count: this.state.count + 1
        // })
        
        // 传入函数，不会被合并。执行结果是 +3
        this.setState((prevState, props) => {
            return {
                count: prevState.count + 1
            }
        })
        this.setState((prevState, props) => {
            return {
                count: prevState.count + 1
            }
        })
        this.setState((prevState, props) => {
            return {
                count: prevState.count + 1
            }
        })
    }
    // bodyClickHandler = () => {
    //     this.setState({
    //         count: this.state.count + 1
    //     })
    //     console.log('count in body event', this.state.count)
    // }
    // componentDidMount() {
    //     // 自己定义的 DOM 事件，setState 是同步的
    //     document.body.addEventListener('click', this.bodyClickHandler)
    // }
    // componentWillUnmount() {
    //     // 及时销毁自定义 DOM 事件
    //     document.body.removeEventListener('click', this.bodyClickHandler)
    //     // clearTimeout
    // }
}

export default StateDemo

// -------------------------- 我是分割线 -----------------------------

// // 不可变值（函数式编程，纯函数） - 数组
// const list5Copy = this.state.list5.slice()
// list5Copy.splice(2, 0, 'a') // 中间插入/删除
// this.setState({
//     list1: this.state.list1.concat(100), // 追加
//     list2: [...this.state.list2, 100], // 追加
//     list3: this.state.list3.slice(0, 3), // 截取
//     list4: this.state.list4.filter(item => item > 100), // 筛选
//     list5: list5Copy // 其他操作
// })
// // 注意，不能直接对 this.state.list 进行 push pop splice 等，这样违反不可变值

// // 不可变值 - 对象
// this.setState({
//     obj1: Object.assign({}, this.state.obj1, {a: 100}),
//     obj2: {...this.state.obj2, a: 100}
// })
// // 注意，不能直接对 this.state.obj 进行属性设置，这样违反不可变值
~~~

setState 在直接使用过程中是一个异步操作，在 setTimeout 及自定义 dom 事件中是同步操作。

## 生命周期

![image-20210821102844862](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210821102844862.png)

## React 高级特性

### 函数组件

当 class 组件里只接收一个 props 渲染结果时，没有 state 等其他逻辑，这时可以通过函数组件代替。

![image-20210821114322554](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210821114322554.png)

![image-20210821114436951](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210821114436951.png)

### 受控组件 vs 非受控组件

![image-20210821114456601](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210821114456601.png)

![image-20210821114529217](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210821114529217.png)

### Portals

![image-20210821150926765](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210821150926765.png)

### React Context

~~~ react
import React from 'react'

// 创建 Context 填入默认值（任何一个 js 变量）
const ThemeContext = React.createContext('light')

// 底层组件 - 函数是组件
function ThemeLink (props) {
    // const theme = this.context // 会报错。函数式组件没有实例，即没有 this

    // 函数式组件可以使用 Consumer
    return <ThemeContext.Consumer>
        { value => <p>link's theme is {value}</p> }
    </ThemeContext.Consumer>
}

// 底层组件 - class 组件
class ThemedButton extends React.Component {
    // 指定 contextType 读取当前的 theme context。
    // static contextType = ThemeContext // 也可以用 ThemedButton.contextType = ThemeContext
    render() {
        const theme = this.context // React 会往上找到最近的 theme Provider，然后使用它的值。
        return <div>
            <p>button's theme is {theme}</p>
        </div>
    }
}
ThemedButton.contextType = ThemeContext // 指定 contextType 读取当前的 theme context。

// 中间的组件再也不必指明往下传递 theme 了。
function Toolbar(props) {
    return (
        <div>
            <ThemedButton />
            <ThemeLink />
        </div>
    )
}

class App extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            theme: 'light'
        }
    }
    render() {
        return <ThemeContext.Provider value={this.state.theme}>
            <Toolbar />
            <hr/>
            <button onClick={this.changeTheme}>change theme</button>
        </ThemeContext.Provider>
    }
    changeTheme = () => {
        this.setState({
            theme: this.state.theme === 'light' ? 'dark' : 'light'
        })
    }
}

export default App
~~~

Context 会用在最外层定义的类似于主题、语言这些公共信息的一些逻辑不复杂的向下传递的数据。

### 异步加载

![image-20210821152805454](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821152805454.png)

~~~ react
import React from 'react'

const ContextDemo = React.lazy(() => import('./ContextDemo'))

class App extends React.Component {
    constructor(props) {
        super(props)
    }
    render() {
        return <div>
            <p>引入一个动态组件</p>
            <hr />
            <React.Suspense fallback={<div>Loading...</div>}>		//等待组件加载完毕
                <ContextDemo/>
            </React.Suspense>
        </div>

        // 1. 强制刷新，可看到 loading （看不到就限制一下 chrome 网速）
        // 2. 看 network 的 js 加载
    }
}

export default App
~~~



### 性能优化 

#### ShouldComponentUpdate（SCU）

![image-20210821153755880](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20210821153755880.png)

在 React 的默认情况下，父组件更新会导致子组件无条件更新。且由于 SCU 默认返回true，会导致一旦触发组件的渲染，会导致对应的所有组件更新，因此有时需要进行上图的优化。  

### PureComponent （纯组件）和 memo

 ![image-20210821160242068](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821160242068.png)

### immutable.js

![image-20210821160810422](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821160810422.png)

![image-20210821160756035](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821160756035.png)

## React 高阶组件

### 关于组建公共逻辑的抽离

![image-20210821161418160](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821161418160.png)

![image-20210821161514013](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821161514013.png)

Render Props

![image-20210821163358748](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821163358748.png)

### Redux

![image-20210821164753768](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821164753768.png)

#### 基本概念

Redux 

![image-20210821170652873](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821170652873.png)



创建一个公共数据集 store，store 通过 reducer 来查看数据，同时通过 Provider 将包裹在里面的所有组件获得 store 中的内容。

![image-20210821174044080](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821174044080.png)

![image-20210821175624648](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821175624648.png)



同时，创建一个 reducer并返回一个函数，state中存放项目中存放的数据

![image-20210821174414443](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821174414443.png)



当组件中需要修改 store 中的值时，需要通过 dispatch 派发 action

![image-20210821174557980](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821174557980.png)



之后在 reducer 中修改如下

![image-20210821174818261](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821174818261.png)



在组件中通过 subscribe 订阅 store，当 store 中的数据发生改变时，里面的内容会被自动执行。

![image-20210821174956998](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821174956998.png)



若想消费 Redux 的能力，需要将定义好的组件通过 connect 包裹一次

通过 mapStateTorops 和 mapDispatchToProps 完成一些操作后，将其传入对应组件。

![image-20210821171505447](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821171505447.png)

#### Redux 工作流程

![image-20210821165534725](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821165534725.png)

![image-20210821170146145](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821170146145.png)

action 本身是同步操作，在做异步操作时，需要引入 redux-thunk 的中间件，将return 的值改为函数

![image-20210821175835384](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821175835384.png)

![image-20210821180008245](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821180008245.png)



## React 原理

### vdom 和 diff 是实现 React 的核心技术

![image-20210821205628052](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821205628052.png)

### JSX本质

![image-20210821205653368](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821205653368.png)

![image-20210821211202721](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821211202721.png)

### 合成事件

![image-20210821211913969](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821211913969.png)

![image-20210821211934998](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821211934998.png)

### setState 和 batchUpdate 机制

![image-20210821212535356](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821212535356.png)

setState 在直接使用过程中是一个异步操作，在 setTimeout 及自定义 dom 事件中是同步操作。

![image-20210821212700727](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821212700727.png)

setState 是异步操作还是同步操作，取决于 batchUpdate 是否命中

![image-20210821213046839](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821213046839.png)

![image-20210821213131937](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821213131937.png)

![](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821213210751.png)

### 组件渲染和更新过程

![image-20210821214351324](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821214351324.png)

![image-20210821214446578](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821214446578.png)

![image-20210821214544543](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821214544543.png)

![image-20210821214725582](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821214725582.png)

![image-20210821214821924](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\React\image-20210821214821924.png)

