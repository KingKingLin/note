# Three.js 基础学习

近期实习的业务需要接触 3D 动画渲染等方面的知识，因此学习了下 ThreeJS，学习过程比较有意思，算是入个门。

对于为什么要学习`Three.js`，详见[https://cloud.tencent.com/developer/news/414060](https://cloud.tencent.com/developer/news/414060)

## Three.js相关概念

>1. Three.JS是基于WebGL的Javascript开源框架，简言之，就是能够实现3D效果的JS库。
>
>2. WebGL是一种Javascript的3D图形接口，把JavaScript和OpenGL ES 2.0结合在一起。
>
>3. OpenGL是开放式图形标准，跨编程语言、跨平台，Javascript、Java 、C、C++ 、 python 等都能支持OpenG ，OpenGL的Javascript实现就是WebGL，另外很多CAD制图软件都采用这种标准。OpenGL ES 2.0是OpenGL的子集，针对手机、游戏主机等嵌入式设备而设计。
>
>4. Canvas是HTML5的画布元素，在使用Canvas时，需要用到Canvas的上下文，可以用2D上下文绘制二维的图像，也可以使用3D上下文绘制三维的图像，其中3D上下文就是指WebGL。
>
>   利用Three.JS可以制作出很多酷炫的3D动画，并且Three.js还可以通过鼠标、键盘、拖拽等事件形成交互，在页面上增加一些3D动画和3D交互可以产生更好的用户体验。

通过`Three.JS`可以实现**全景视图**，这些**全景视图**应用在房产、家装行业能够带来更直观的视觉体验。在电商行业利用`Three.JS`可以实现产品的3D效果，这样用户就可以**360度全方位**地观察商品了，给用户带来更好的购物体验。另外，使用`Three.JS`还可以制作类似微信跳一跳那样的小游戏。随着技术的发展、基础网络的建设，`web3D`技术还能得到更广泛的应用。

## 主要组件

为了真正能够让你的场景借助`three.js`来进行显示，我们需要以下几个对象：场景（scene）、相机（camera）和渲染器（renderer） 这3个组建才能透过摄像机渲染出场景,将物体渲染到网页中去。

1. 场景

   场景相当于一个容器，带这个容器中包含了各种物品，可以想象成一个房间中可以布置背景、摆放拍摄的物品、添加灯光设备等。

2. 相机

   相机即用来拍摄物品，给用户直观的感受就是通过拍摄角度和位置的不同来得到不同的图像（类似于素描写生）。在学习中我一般使用透视相机，其模拟的效果与人眼看到的景象最接近，在3D场景中也使用得最普遍，这种相机最大的特点就是近大远小，能够相对于相机远近形成不同大小的物体。

3. 渲染器

   渲染器利用场景和相机进行渲染，最终在浏览器中显示。值得注意的是，一般情况下只渲染一次，即静态的图像。可利用`requestAnimationFrame`实现高效的连续渲染形成动态动画。

~~~javascript
//	渲染循环
function animate() {
	requestAnimationFrame( animate );
	renderer.render( scene, camera );
}
animate();

//	requestAnimationFrame有很多的优点。最重要的一点或许就是当用户切换到其它的标签页时，它会暂停，因此不会浪费用户宝贵的处理器资源，也不会损耗电池的使用寿命。
~~~

具体的文档内容详见[Three.js 官方文档](https://threejs.org/)，需要使用者了解基础 API 及使用方法方可使用。虽然官方文档的叙述比较精简，但跟着文档创建一个基础场景能够极大的有利于接下来的学习。

## 基础练习

有了以上的学习基础后，我们可以接触一些相对容易的练习。

### 练习前所需准备

值得注意的是，直接在`js`文件中使用 import 引入 Three.js 会导致报错。因为从第三方导入ES6模块时，仅使用浏览器同步是行不通的。

因为采用import导入相关模块时采用了bare import，如：

~~~javascript
import * from 'three';
~~~

如：上面导入的‘three’，

bare import是使用像Webpack这样的捆绑器时通常会看到的导入，它不是指向node_modules的相对路径，而是映射到了打包发布的路径，例如 通过Webpack打包发布后是可以正常工作的， 但是，如果直接在浏览器中运行，则会看到：

<font color="#FF0000" size=3>**Uncaught TypeError: Failed to resolve module specifier "three". Relative references must start with either "/", "./", or "../".**</font>

针对此问题，我们有两种解决方案 =>

1. 直接引用在线库

   ~~~
   import * from 'https://cdn.skypack.dev/three@v0.133.1';
   ~~~

2. 通过打包工具进行打包（Webpack、Vite、Rollup .etc）

因为是练习，此处不使用相对麻烦的打包方式，采用引用在线库来使用。

### 3维物体的展示练习

为了熟悉物体在三维场景中的应用，这里我们建立一个空间直角坐标系（Three.JS 使用右手坐标系，这源于OpenGL默认情况下，也是右手坐标系。）

首先，我们创建一个`html`，用来显示页面的相关内容。

~~~html
<html>
	<head>
		<meta charset="utf-8">
		<title>My first three.js app</title>
		<style>
			body { 
				margin: 0;
				overflow: hidden;
			}
		</style>
	</head>
	<body>
		<script src="./js/three.js"></script>
		<script src="./js/3DModel.js" type="module">
		</script>
	</body>
</html>
~~~

接下来我们在`3DModel.js`中构建内容。

~~~javascript
import { GLTFLoader } from 'https://cdn.skypack.dev/three@v0.133.1/examples/jsm/loaders/GLTFLoader.js';

function init() {
	//	 创建场景
	const scene = new THREE.Scene();
	//	设置摄像机	
	const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 2000)
	//	渲染器
	const renderer = new THREE.WebGLRenderer({antialias:true});
	//	设置渲染器初始颜色
	renderer.setClearColor(new THREE.Color(0xEEEEEE))
	//	设置输出 canvas 画面的大小
	renderer.setSize(window.innerWidth, window.innerHeight)
    
	//	显示三维坐标系
	const axes = new THREE.AxesHelper(20)

	//	添加坐标系到场景中
	scene.add(axes);

	//	定位相机， 并且指向场景中心
	camera.position.x = 30
	camera.position.y = 30
	camera.position.z = 30;
	camera.lookAt(scene.position)

	//	将渲染器输出添加到html元素中
	document.body.appendChild( renderer.domElement );
	renderer.render(scene, camera)
}

window.onload = init

~~~

使用`VSCode插件`插件`Live Server`创建一个简易本地服务器运行，结果如下

![image-20211021155901825](C:\Users\Kirito\AppData\Roaming\Typora\typora-user-images\image-20211021155901825.png)

可以看到，我们构建了一个由X轴（红线）、Y轴（绿线）、Z轴（蓝线）组成的空间坐标系。接下来的工作也只是做加法，首先我们再添加一个地面，并创建聚光灯，用以投射阴影。

~~~javascript
function init() {
	const scene = new THREE.Scene();
	const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 2000)
	const renderer = new THREE.WebGLRenderer({antialias:true});
	renderer.setClearColor(new THREE.Color(0xEEEEEE))
	renderer.setSize(window.innerWidth, window.innerHeight)
	
    //	设置渲染物体阴影
	renderer.shadowMap.enabled = true;
	renderer.shadowMap.type = THREE.PCFSoftShadowMap;
	
	const axes = new THREE.AxesHelper(20)
	scene.add(axes);

	const planeGeometry = new THREE.PlaneGeometry(60, 20);
	//	给地面物体上色
	const planeMaterial = new THREE.MeshLambertMaterial({color: 0xcccccc});
	//	创建地面
	const plane = new THREE.Mesh(planeGeometry, planeMaterial)

	//	物体移动位置
	plane.rotation.x = -0.5 * Math.PI;
	plane.position.x = 0
	plane.position.y = 0;
	plane.position.z = 0;
	plane.castShadow = true
	//	接收阴影
	plane.receiveShadow = true;

	//将地面添加到场景中
	scene.add(plane)

	//	创建聚光灯
	const spotLight= new THREE.SpotLight(0xffffff);
	spotLight.position.set(30, 30, -30)
	spotLight.castShadow = true;

	//	添加聚光灯
	scene.add(spotLight)

	spotLight.shadow.mapSize.width = 512;
	spotLight.shadow.mapSize.height = 512;

	spotLight.shadow.camera.near = 0.1;
	spotLight.shadow.camera.far = 1000;
	spotLight.shadow.camera.fov = 1;

	//	定位相机， 并且指向场景中心
	camera.position.x = 30
	camera.position.y = 30
	camera.position.z = 30;
	camera.lookAt(scene.position)

	//	将渲染器输出添加到html元素中
	document.body.appendChild( renderer.domElement );
	renderer.render(scene, camera)
}

window.onload = init
~~~

![image-20211021160848356](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Three.js\image-20211021160848356.png)

由此，我们得到了地面和光，接下来就是放置物体

~~~javascript
	//	添加立方体
	const cubeGeometry = new THREE.BoxGeometry(4, 4, 4)
	const cubeMaterial = new THREE.MeshLambertMaterial({color: 0xff0000})
	const cube = new THREE.Mesh(cubeGeometry, cubeMaterial)
	
	cube.position.x = 0;
	cube.position.y = 4;
	cube.position.z = 2;

	//	球体
	const sphereGeometry = new THREE.SphereGeometry(3, 20, 20);		//	半径，经度， 维度
	const sphereMaterial = new THREE.MeshLambertMaterial({color: 0xff0000})
	const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial)

	sphere.position.x = 13;
	sphere.position.y = 5;
	sphere.position.z = -3;

	// 对象是否渲染到阴影贴图当中
	cube.castShadow = true;
	sphere.castShadow = true;

	scene.add(cube)
	scene.add(sphere)
	
	//	...以下补充到代码最后
	const helper = new THREE.CameraHelper( spotLight.shadow.camera );
	scene.add( helper );

	let T0 = new Date()

	function render() {
		let T1 = new Date()
		let t = T1 - T0;
		T0 = T1;
		renderer.render(scene, camera)
		//	每次绕 Y 轴 旋转 0.01 弧度
		//	每一毫秒渲染 0.001 弧度
		cube.rotateY(0.001 * t)
		window.requestAnimationFrame(render)
	}
	// setInterval(render, 16)
	//	请求动画帧
	window.requestAnimationFrame(render)
}

window.onload = init
~~~



![image-20211021154019217](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Three.js\image-20211021154019217.png)

通过上述内容，我们构建了一个由X轴（红线）、Y轴（绿线）、Z轴（蓝线）组成的空间坐标系，并且放置了一个球体和一个旋转的正方体，将他们被聚光灯照射产生的阴影渲染在地面上。

画面中多余的线条实际上是辅助线，基于`THREE.CameraHelper`来指示光的照射范围、定位指向等。



由此我们完成了**3D物体**在浏览器的显示过程，美中不足的是我们只能从一个固定的面去观察它，有时我们需要通过拖拽实现不同角度的观察。因此我们添加一下代码

~~~javascript
import { OrbitControls } from 'https://cdn.skypack.dev/three@v0.133.1/examples/jsm/controls/OrbitControls.js';

function init() {
  //  ...以下为新增内容
  //  创建 controls 对象
  const controls = new OrbitControls(camera, renderer.domElement)
  //  监听鼠标事件，执行渲染内容
  controls.addEventListener('click', () => {
    renderer.render(scene, camera)
  })
}

window.onload = init
~~~

![image-20211021162009675](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Three.js\image-20211021162009675.png)

![image-20211021161953768](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Three.js\image-20211021161953768.png)

此时，我们可以从不同角度观测物体，并且可以观察到聚光灯的位置及其详细情况。



## 进阶练习

有了上述学习的基础，我们可以统筹一些内容实现一个地月环绕系统。首先我们需要去下载一些3D贴图，来为自己的3D模型增添样式。

![image-20211021162430756](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Three.js\image-20211021162430756.png)

在此处，需要使用 `textureLoader` 纹理加载器，将样式 与3D模型合并，为地球实现凹凸不平的地貌及云层等外观。

具体情况详见下述代码。

~~~html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="chrome=1">
    <meta http-equiv="Access-Control-Allow-Origin" content="*" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
      * { 
        margin: 0;
        padding: 0;
      }
      canvas {
        background-image: url(img/stars1.jpg);
        background-size: contain;
      }

      .label {
        color: #fff;
        font-size: 16px
      }
    </style>
    <script type="module">
      import * as THREE from 'https://cdn.skypack.dev/three@v0.133.1/build/three.module.js'  
      import { OrbitControls } from 'https://cdn.skypack.dev/three@v0.133.1/examples/jsm/controls/OrbitControls.js'
      import { CSS2DRenderer, CSS2DObject } from 'https://cdn.skypack.dev/three@v0.133.1/examples/jsm/renderers/CSS2DRenderer.js'

      //  声明全局变量
      let camera, scene, renderer, labelRenderer;
      let moon, earth = new THREE.Group();
      let clock = new THREE.Clock();   //时钟
      //  实例化纹理加载器
      const textureLoader = new THREE.TextureLoader();
      
      //  设置初始化函数
      function init() {
        //  地球 和 月球 半径大小
        const EARTH_RADIUS = 2.5;
        const MOON_RADIUS = 0.5;
        //  实例化相机（采用透视）
        camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 200);
        camera.position.set(10, 5,20)

        //  实例化场景
        scene = new THREE.Scene();
        //  创建聚光灯光源
        const dirLight = new THREE.SpotLight(0xffffff);
        dirLight.position.set(0, 0, 10);
        dirLight.intensity = 2;   //  设置亮度
        dirLight.castShadow = true;
        scene.add(dirLight)

        //  添加环境光
        const aLight = new THREE.AmbientLight(0xffffff)
        aLight.intensity = 0.37    //  调节光亮度
        scene.add(aLight)

        //  创建月球
        const moonGeometry = new THREE.SphereGeometry(MOON_RADIUS, 16, 16)
        const moonMaterial = new THREE.MeshPhongMaterial({
          //  textureLoader 纹理加载器
          map: textureLoader.load('./models/planets/MoonTexture.bmp')
        })
        moon = new THREE.Mesh(moonGeometry, moonMaterial)
        moon.receiveShadow = true;
        moon.castShadow = true;
        scene.add(moon)

        //  创建地球
        const earthGeometry = new THREE.SphereGeometry(EARTH_RADIUS, 16, 16)
        const eatchMaterial = new THREE.MeshPhongMaterial({
          shininess: 5, //  调节镜面反射
          map: textureLoader.load('./models/planets/EarthTexture.jpg'),
          specularMap: textureLoader.load('./models/planets/Spec_Mask.png'),
          bumpMap: textureLoader.load('./models/planets/Bump.jpg'),
          lightMap: textureLoader.load('./models/planets/Night_Lights.jpg'),
        })
        const cloudGeometry = new THREE.SphereGeometry( EARTH_RADIUS + 0.1, 16, 16 );
        const cloudMaterial = new THREE.MeshPhongMaterial({ 
          alphaMap: textureLoader.load('./models/planets/Clouds.png'),
          opacity: 1,
          transparent: true
        })

        const earthMesh = new THREE.Mesh(earthGeometry, eatchMaterial);
        const cloudMesh = new THREE.Mesh(cloudGeometry, cloudMaterial);
        earth.add(earthMesh)
        earth.add(cloudMesh)
        cloudMesh.receiveShadow = true
        cloudMesh.castShadow = true;
        
        scene.add(earth)

        const earthDiv = document.createElement('div');
        earthDiv.className = 'label';
        earthDiv.textContent = 'Earth';
        const earthLabel = new CSS2DObject(earthDiv)

        earthLabel.position.set(0, EARTH_RADIUS + 0.5, 0)
        earth.add(earthLabel)

        const moonDiv = document.createElement('div');
        moonDiv.className = 'label';
        moonDiv.textContent = 'Moon';
        const moonLabel = new CSS2DObject(moonDiv)

        moonLabel.position.set(0, MOON_RADIUS + 0.5, 0)
        moon.add(moonLabel)

        //  创建渲染器
        renderer= new THREE.WebGLRenderer({
          antialias: true,
          alpha: true
        });
        renderer.setPixelRatio(window.devicePixelRatio);    //  设置像素比
        renderer.setSize(window.innerWidth, window.innerHeight)
        //  渲染阴影
        renderer.shadowMap.enabled = true;
        document.body.appendChild(renderer.domElement)

        //  标签渲染器
        labelRenderer = new CSS2DRenderer();
        labelRenderer.setSize(window.innerWidth, window.innerHeight)
        labelRenderer.domElement.style.position = 'absolute';
        labelRenderer.domElement.style.top = '0px'
        const labelControls = new OrbitControls(camera, labelRenderer.domElement)
        document.body.appendChild(labelRenderer.domElement)

        //  绑定控制器和摄像头
        //const controls = new OrbitControls(camera, renderer.domElement)
      
        //const helper = new THREE.CameraHelper( dirLight.shadow.camera );
        //scene.add( helper );
      }

      let oldTime = 0;

      function animate() {
        const elapsed = clock.getElapsedTime();
        moon.position.set(Math.sin(elapsed) * 5, 0, Math.cos(elapsed) * 5);

        //  地球自转
        const axis = new THREE.Vector3(0,1,0);
        //  围绕上面定义的向量轴进行旋转
        earth.rotateOnAxis(axis, (elapsed - oldTime) * Math.PI / 10)
        renderer.render(scene, camera)
        labelRenderer.render(scene, camera)
        oldTime = elapsed;
        requestAnimationFrame(animate)
        
      }
      init()
      animate()

      //  调整尺寸
      window.onresize = function() {
        camera.aspect = window.innerWidth / window.innerHeight
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight)
      }
    </script>
  </head>
  <body>

  </body>
</html>
~~~

<video src="C:\Users\Kirito\Desktop\QQ录屏20211021165843.mp4"></video>

由此，我们实现了地月环绕系统，即地球自转 + 月球公转的双星系统。我们可以通过鼠标左键旋转视角，鼠标右键拉动观测位置。同时，月球在转至有光线照射的一面时还会向地球留下投影。

## 总结

借用知乎某位大佬的阐述，

> three.js的基本组件关系如下图所示：
>
> ![v2-a4cf2c06622bf6aceb4fa3dc1d2c766b_r](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Three.js\v2-a4cf2c06622bf6aceb4fa3dc1d2c766b_r.png)
>
> 
>
> 如果你感觉还是不好理解各组件的作用和关系，那么我们对照一下真实世界的视觉形成逻辑就更好理解了：
>
> ![v2-e30bb9e778c1144e97d34ddf58ebddd1_720w](D:\前端学习\vuepress-starter\docs\.vuepress\public\img\Three.js\v2-e30bb9e778c1144e97d34ddf58ebddd1_720w.png)



学习下来感觉可能相对来说会比较抽象，但在一些简单场景来说对于人的第一感觉能够直观地想象出来。`Three.js` 作为一款开源的主流3D绘图JS引擎，极大的方便了前端人员完成3D绘图工作。
