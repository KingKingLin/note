# 关于 TypeScript 的学习

`TypeScript`  中**最最最重要**的就是 `type`。这凸显了它的特性——即有类型的 `JavaScript`。

事实上，`JavaScript`作为一个弱类型的语言，在执行环境中允许数据类型随意更改。例如：

~~~javascript
let a = 'Hoshiu'	//String
a = 2		//Number
~~~

而在 `TS` 中，则会报错

~~~
let a = 'Hoshiu'	//String
a = 2		//Type '2' is not assignable to type 'string'
~~~

原因在于当你在 `TS` 中声明了`a`是`string`类型后，在后续就应当一直遵循该类型，因此修改为`Number`类型时会报错。

诚然，谁都不会做无意义的事。这样做存在着诸多好处。

1. 我们可以指定在某一函数中接收的参数类型，只要知道参数的类型，在调用该函数时，非常**安全**地使用该类型上面的方法。

   ~~~
   // TS写法
   function fuc(a: string) {	//强类型，已经确保了 a 是 string 类型
   	return a.substring(1)
   }
   
   //JS写法
   function fucA(a) {
   	if(typeof a === 'string')	//如果是 JS 运行环境下，需要首先判断类型才能使用其方法
   	return a.substring(1)
   }
   ~~~

   

2. 使得程序跟更容易理解。约定相关函数的返回值类型，不必再需要在控制台输出查看。

3. 可以非常方便地在不同代码块和定义中进行跳转，代码能够自动补全，有用丰富的接口提示。

   ~~~
   jQuery.
   //下拉补全框，涵盖了jQuery中的方法
   length makeArray map merge name noConflict nodeName...
   ~~~

4. 在编译期间能够发现大部分错误，比如一个方法不存在时即会报错。

5. TS 存在非常好的包容性，作为 JS 的超集，它完美兼容 JS，且兼容第三方库。即使该库是由 JS 编写的，但它会提供写好的类型文件供开发者使用，做到无缝衔接。

## 如何用 TS 在 Vue3 中定义组件

我们在`App.vue`中写一个非常简单的实例

~~~vue
//App.vue
<script lang="ts">
import { defineComponent, PropType } from 'vue'
import HelloWorld from './components/HelloWorld.vue'

interface Config {
  name: string
}

export default defineComponent({
  name: 'App',
  props: {
    age: {
      type: Number as PropType<number>,
    },
    config: {
      type: Object as PropType<Config>,
      required: true,
    }
  },
  components: {
    HelloWorld,
  },
  data () {
    return {
      name: 'Hoshiu',
    }
  },
  mounted() {
    this.config
  },
})
</script>
~~~

`defineComponent` 函数用来定义 `Vue3` 当中的组件，它返回了组件的定义。

使用 `PropType ` 来定义`TS` 的数据类型。

